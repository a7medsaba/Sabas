#!/bin/bash
python bot/main.py